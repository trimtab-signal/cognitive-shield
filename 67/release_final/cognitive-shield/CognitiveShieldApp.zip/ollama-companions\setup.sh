#!/bin/bash
# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║   OLLAMA COMPANIONS SETUP SCRIPT                                          ║
# ║   Creates all 5 companions for the Geodesic Exocortex                     ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

set -e

echo "╔═══════════════════════════════════════════════════════════════════════════╗"
echo "║   OLLAMA COMPANIONS SETUP                                                 ║"
echo "╚═══════════════════════════════════════════════════════════════════════════╝"
echo ""

# Check if Ollama is installed
if ! command -v ollama &> /dev/null; then
    echo "❌ Ollama is not installed."
    echo "   Please install from: https://ollama.ai/download"
    exit 1
fi

echo "✅ Ollama found"
echo ""

# Check if llama3 is available
echo "📦 Checking for base model (llama3)..."
if ! ollama list | grep -q "llama3"; then
    echo "   Pulling llama3 base model (this may take a while)..."
    ollama pull llama3
else
    echo "   ✅ llama3 already available"
fi
echo ""

# Create companions
echo "🔧 Creating companions..."
echo ""

echo "1️⃣  Creating Cognitive Shield..."
ollama create cognitive-shield -f Modelfile.cognitive-shield
echo "   ✅ Cognitive Shield created"
echo ""

echo "2️⃣  Creating Somatic Regulator..."
ollama create somatic-regulator -f Modelfile.somatic-regulator
echo "   ✅ Somatic Regulator created"
echo ""

echo "3️⃣  Creating GenSync Operator..."
ollama create gensync-operator -f Modelfile.gensync-operator
echo "   ✅ GenSync Operator created"
echo ""

echo "4️⃣  Creating Staircase Strategist..."
ollama create staircase-strategist -f Modelfile.staircase-strategist
echo "   ✅ Staircase Strategist created"
echo ""

echo "5️⃣  Creating Truth Anchor..."
ollama create truth-anchor -f Modelfile.truth-anchor
echo "   ✅ Truth Anchor created"
echo ""

echo "╔═══════════════════════════════════════════════════════════════════════════╗"
echo "║   ✅ ALL COMPANIONS CREATED SUCCESSFULLY                                  ║"
echo "╚═══════════════════════════════════════════════════════════════════════════╝"
echo ""
echo "📋 Available companions:"
ollama list | grep -E "(cognitive-shield|somatic-regulator|gensync-operator|staircase-strategist|truth-anchor)"
echo ""
echo "🧪 Test a companion:"
echo "   ollama run cognitive-shield \"Test message: We need to talk.\""
echo ""
echo "📚 See README.md for usage examples and integration with daily sequences."
echo ""



