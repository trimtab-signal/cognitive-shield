# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║   OLLAMA COMPANIONS SETUP SCRIPT (PowerShell)                                ║
# ║   Creates all 5 companions for the Geodesic Exocortex                     ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

Write-Host "╔═══════════════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║   OLLAMA COMPANIONS SETUP                                                 ║" -ForegroundColor Cyan
Write-Host "╚═══════════════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# Check if Ollama is installed
try {
    $ollamaVersion = ollama --version 2>&1
    Write-Host "✅ Ollama found" -ForegroundColor Green
} catch {
    Write-Host "❌ Ollama is not installed." -ForegroundColor Red
    Write-Host "   Please install from: https://ollama.ai/download" -ForegroundColor Yellow
    exit 1
}

Write-Host ""

# Check if llama3 is available
Write-Host "📦 Checking for base model (llama3)..." -ForegroundColor Yellow
$ollamaList = ollama list 2>&1
if ($ollamaList -notmatch "llama3") {
    Write-Host "   Pulling llama3 base model (this may take a while)..." -ForegroundColor Yellow
    ollama pull llama3
} else {
    Write-Host "   ✅ llama3 already available" -ForegroundColor Green
}
Write-Host ""

# Create companions
Write-Host "🔧 Creating companions..." -ForegroundColor Cyan
Write-Host ""

Write-Host "1️⃣  Creating Cognitive Shield..." -ForegroundColor Yellow
ollama create cognitive-shield -f Modelfile.cognitive-shield
Write-Host "   ✅ Cognitive Shield created" -ForegroundColor Green
Write-Host ""

Write-Host "2️⃣  Creating Somatic Regulator..." -ForegroundColor Yellow
ollama create somatic-regulator -f Modelfile.somatic-regulator
Write-Host "   ✅ Somatic Regulator created" -ForegroundColor Green
Write-Host ""

Write-Host "3️⃣  Creating GenSync Operator..." -ForegroundColor Yellow
ollama create gensync-operator -f Modelfile.gensync-operator
Write-Host "   ✅ GenSync Operator created" -ForegroundColor Green
Write-Host ""

Write-Host "4️⃣  Creating Staircase Strategist..." -ForegroundColor Yellow
ollama create staircase-strategist -f Modelfile.staircase-strategist
Write-Host "   ✅ Staircase Strategist created" -ForegroundColor Green
Write-Host ""

Write-Host "5️⃣  Creating Truth Anchor..." -ForegroundColor Yellow
ollama create truth-anchor -f Modelfile.truth-anchor
Write-Host "   ✅ Truth Anchor created" -ForegroundColor Green
Write-Host ""

Write-Host "6️⃣  Creating Geometrix (3D Design)..." -ForegroundColor Yellow
ollama create geometrix -f Modelfile.geometrix
Write-Host "   ✅ Geometrix created" -ForegroundColor Green
Write-Host ""

Write-Host "╔═══════════════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║   ✅ ALL 6 COMPANIONS CREATED SUCCESSFULLY                                ║" -ForegroundColor Green
Write-Host "╚═══════════════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

Write-Host "📋 Available companions:" -ForegroundColor Yellow
ollama list | Select-String -Pattern "(cognitive-shield|somatic-regulator|gensync-operator|staircase-strategist|truth-anchor)"
Write-Host ""

Write-Host "🧪 Test a companion:" -ForegroundColor Yellow
Write-Host "   ollama run cognitive-shield `"Test message: We need to talk.`"" -ForegroundColor Gray
Write-Host ""

Write-Host "📚 See README.md for usage examples and integration with daily sequences." -ForegroundColor Cyan
Write-Host ""

