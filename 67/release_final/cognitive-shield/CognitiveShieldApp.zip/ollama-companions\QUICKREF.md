# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║   OLLAMA COMPANIONS - QUICK REFERENCE                                      ║
# ║   Print this. Keep it handy.                                              ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

## 🚀 SETUP (One Time)

```bash
# 1. Install Ollama: https://ollama.ai/download
# 2. Pull base model
ollama pull llama3

# 3. Create all companions
cd ollama-companions
./setup.ps1  # Windows
# OR
./setup.sh   # Linux/Mac
```

---

## 🎯 COMPANION SELECTION

| What You Need | Use This | Command |
|---------------|----------|---------|
| 📧 Process incoming message | **Cognitive Shield** | `ollama run cognitive-shield "Message: [text]"` |
| 😰 Feeling overwhelmed | **Somatic Regulator** | `ollama run somatic-regulator "I'm feeling [state]"` |
| 💬 Rewrite message for someone | **GenSync Operator** | `ollama run gensync-operator "GenSync: Rewrite for [person]. Message: [draft]"` |
| 💰 Financial decision | **Staircase Strategist** | `ollama run staircase-strategist "[question]"` |
| 🤔 Existential crisis | **Truth Anchor** | `ollama run truth-anchor "[situation]"` |

---

## 📋 DAILY USAGE PATTERNS

### **Morning (Startup)**
```bash
# Process first 3 messages
ollama run cognitive-shield "Message: [paste message]"
```

### **Throughout Day**
```bash
# Before sending important message
ollama run gensync-operator "GenSync: Rewrite for [person]. Message: [draft]"

# Financial question
ollama run staircase-strategist "Should I [action]? What phase am I in?"
```

### **Evening (Shutdown)**
```bash
# Process remaining messages
ollama run cognitive-shield "Message: [batch all messages]"

# If overwhelmed
ollama run somatic-regulator "I'm feeling [state]. What's the protocol?"

# Grounding
ollama run truth-anchor "Remind me of the Immutable Primitives."
```

---

## 🚨 EMERGENCY PROTOCOLS

### **High Voltage Message**
1. `ollama run cognitive-shield "Message: [text]"` → Get voltage score
2. If Voltage > 7: `ollama run somatic-regulator "STATE OVERLOAD. Execute meltdown SOP."`
3. Defer response until calm

### **Social Conflict**
1. `ollama run gensync-operator "/scan this interaction. Stability score?"`
2. `ollama run truth-anchor "What Primitive is broken?"`
3. `ollama run gensync-operator "Fix this using [HumanOS] translation."`

### **Financial Crisis**
1. `ollama run staircase-strategist "What phase am I in? What's the trimtab?"`
2. `ollama run staircase-strategist "Calculate runway. How many units to cover [expense]?"`

---

## 🛡️ COGNITIVE SHIELD - PROMPTS

### **Incoming Message (Scrubber)**
```
Act as a Communication Mediator. I am pasting a text. Do NOT repeat the raw text. Process it using the established protocol:
1. BLUF Summary: Emotion-neutral summary of the ask.
2. Voltage Check: Rate intensity (Low/Med/High) and identify triggers.
3. The Translation: Rewrite the message to be calm, clear, and kind.
4. The Why: Explain the sender's likely state.
Message: [paste here]
```

### **Outgoing Message (Impedance Matcher)**
```
I need to reply to this. My draft is below. Rewrite it to remove my defensiveness. Translate my thoughts into a language the recipient can hear without getting triggered. Focus on [Goal/Context].
My Draft: [paste here]
```

---

## 🔧 GENSYNC OPERATOR - LEVELS

### **L1 (Novice) - Fix-It Button**
```
GenSync: Rewrite this message for my boss.
Message: [draft]
```

### **L2 (Operator) - Vibe Check**
```
/scan this chat log. What is the stability score?
```

### **L3 (Architect) - System Refactor**
```
/stabilize this module. Check for Paralleling violations.
```

---

## 📐 THE 4 PRIMITIVES (GenSync/Truth Anchor)

1. **FREQUENCY** (Heartbeat): Everything needs a rhythm
2. **PARALLELING** (Equalizer): Share the load
3. **BINARY LOGIC** (The Cut): YES or NO, no maybe
4. **TETRAHEDRON** (Geometry): Need 4 nodes for stability

---

## 🎯 HUMANOS TRANSLATION MATRIX

| Type | Keywords |
|------|----------|
| **Winner** (Achiever) | Win, Profit, Fast, Strategy, ROI, Results |
| **Builder** (Integrator) | System, Flow, Design, Function, Architecture |
| **Soldier** (Order) | Rules, Duty, Standard, Correct, Protocol |
| **Wolf** (Guardian) | Power, Respect, Pack, Forbidden, Loyalty |
| **Healer** (Empath) | Vibe, Community, Feelings, Together, Harmony |

---

## 🏗️ STAIRCASE PHASES

1. **TRIMTAB**: Liquidate dead capital (70% value, velocity > value)
2. **BRIDGE**: Small batch manufacturing ($47 profit/unit, 36 units/month)
3. **MESH**: Sovereign infrastructure (LoRa, $200-300/unit)
4. **DAO**: Protocol ownership (Abdication Value, Book Name)

---

## 🧘 SOMATIC REGULATOR - STATES

- **IDLE**: Homeostasis, neutral
- **ACTIVE**: Engagement, displaying status
- **OVERLOAD**: Crisis mode, execute meltdown SOP

**Meltdown SOP:**
1. Stop Moving
2. Activate Noise Cancellation
3. Check Heart Rate
4. Navigate to Safe Zone

---

## 💎 TRUTH ANCHOR - IMMUTABLE PRIMITIVES

1. **Frequency**: Stability comes from rhythm
2. **Equalizer**: Stability comes from shared load
3. **The Cut**: Stability comes from binary clarity
4. **Tetrahedron**: Stability comes from 4-node redundancy

**Core Philosophy:**
- Pain = Heat from Impedance Mismatch (engineering failure, not moral)
- Trust = Geometric ($K_4$ Graph)
- Truth = Lossless Container (Tetrahedron)
- Love = Impedance Matching

---

**Remember:** These are tools, not rules. Use what works. Skip what doesn't.  
**The goal is Zero Impedance, not perfection.**



