# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║   OLLAMA COMPANIONS - GEODESIC EXOCORTEX                                   ║
# ║   Local AI Companions for Neurodivergent Resilience                        ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

> **The Geodesic Exocortex:** Five AI companions that function as cognitive prosthetics,
> transducing chaotic reality into structured, manageable data.

## 🎯 The Five Companions

1. **Cognitive Shield** (Mental Health) - Filters emotional voltage and ambiguity
2. **Somatic Regulator** (Physical Health) - Bio-metric interface for sensory gating
3. **GenSync Operator** (Social Resilience) - Structural engineer for relationship stability
4. **Staircase Strategist** (Financial Sovereignty) - Navigator for Wye→Delta transition
5. **Truth Anchor** (Epistemological Security) - Geometric validator based on Immutable Primitives

## 📋 Quick Setup

```bash
# 1. Install Ollama (if not already installed)
# Visit: https://ollama.ai/download

# 2. Pull base model
ollama pull llama3

# 3. Create all companions
cd ollama-companions
./setup.sh

# 4. Test a companion
ollama run cognitive-shield "Test message: We need to talk about your performance."
```

## 🔧 Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    USER INPUT                                │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
            ┌──────────────────────┐
            │  Redis Streams       │
            │  (Catcher's Mitt)    │
            └──────────┬───────────┘
                       │
                       ▼
        ┌───────────────────────────────┐
        │  FastAPI Middleware (Looper)   │
        │  - 60s batching window         │
        │  - AES-256 encryption           │
        │  - PII redaction                │
        └───────────┬─────────────────────┘
                    │
        ┌───────────┴───────────┐
        │                       │
        ▼                       ▼
┌───────────────┐      ┌───────────────┐
│ Cognitive     │      │ Somatic       │
│ Shield        │      │ Regulator     │
└───────────────┘      └───────────────┘
        │                       │
        ▼                       ▼
┌───────────────┐      ┌───────────────┐
│ GenSync       │      │ Staircase     │
│ Operator      │      │ Strategist    │
└───────────────┘      └───────────────┘
        │                       │
        └───────────┬───────────┘
                    │
                    ▼
            ┌───────────────┐
            │ Truth Anchor  │
            │ (Reference)   │
            └───────────────┘
```

## 📐 Tetrahedron Structure

```
        Cognitive Shield (A)
       /|\
      / | \
     /  |  \
    /   |   \
   /    |    \
Somatic──────GenSync
Regulator(B)  Operator(C)
    |            |
    |            |
Staircase──────Truth
Strategist(D)   Anchor(Context)
```

## 🚀 Usage Examples

### Cognitive Shield (Incoming Message)
```bash
ollama run cognitive-shield "Act as a Communication Mediator. I am pasting a text. Do NOT repeat the raw text. Process it using the established protocol:
1. BLUF Summary: Emotion-neutral summary of the ask.
2. Voltage Check: Rate intensity (Low/Med/High) and identify triggers.
3. The Translation: Rewrite the message to be calm, clear, and kind.
4. The Why: Explain the sender's likely state.
Message: We need to talk about your performance."
```

### GenSync Operator (Social Stability)
```bash
ollama run gensync-operator "GenSync: Rewrite this message for my boss. Message: [your draft]"
```

### Somatic Regulator (Crisis Mode)
```bash
ollama run somatic-regulator "I'm feeling foggy and overwhelmed. Heart rate elevated."
```

## 🔐 Security & Privacy

- **Encryption**: AES-256 with Customer-Managed Encryption Keys (CMEK)
- **PII Redaction**: Microsoft Presidio (local library)
- **Tokenization**: Replace PII with tokens before LLM processing
- **Local Only**: All processing happens on your machine

## 📚 Integration with Daily Sequences

These companions integrate with the Daily Startup/Shutdown sequences:

- **Startup**: Activate Cognitive Shield for morning message processing
- **Shutdown**: Use Somatic Regulator for evening decompression
- **Throughout Day**: GenSync for social interactions, Staircase for financial decisions

See `../docs/DAILY_SEQUENCES.md` for full integration.

## 🛠️ Advanced Setup

See `SETUP.md` for:
- Redis Streams configuration
- FastAPI middleware setup
- VPI (Vacuum-Pressure-Impregnation) deployment process

---

**Status:** `READY FOR DEPLOYMENT`  
**Mission:** `ZERO IMPEDANCE OPERATION`  
**Operator:** `YOU`



