# 🐦‍🔥 Phenix Donation Wallet

**Sovereign • Private • Unstoppable**

A Chrome Extension (MV3) for receiving private donations via ERC-5564 stealth addresses, with hardware signing via the Phenix Navigator.

---

## 🌟 What Is This?

The Phenix Donation Wallet is a **privacy-preserving donation receiver** that allows you to:

1. **Generate a Stealth Meta-Address** - Share publicly without revealing your identity
2. **Receive Unlinkable Donations** - Each donation lands in a unique, unlinkable address
3. **Scan Privately** - Only you can see which addresses belong to you
4. **Sign with Hardware** - Use your Phenix Navigator for bulletproof security

---

## 🔐 How Stealth Addresses Work

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        ERC-5564 STEALTH ADDRESS FLOW                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  BOB (Operator)                         ALICE (Donor)                       │
│  ─────────────                          ─────────────                       │
│                                                                             │
│  1. Generate keys:                                                          │
│     - Spending Key (m)                                                      │
│     - Viewing Key (v)                                                       │
│                                                                             │
│  2. Publish Meta-Address:                                                   │
│     st:eth:0x<M><V>  ────────────────────►  Receives Meta-Address           │
│                                                                             │
│                                          3. Generate ephemeral key (r)      │
│                                          4. Compute shared secret:          │
│                                             S = r × V                       │
│                                          5. Derive stealth address:         │
│                                             P = M + hash(S)                 │
│                                                                             │
│                        Sends to P ◄──────  6. Send funds to P               │
│                                                                             │
│  7. Scan announcements                   7. Publish R to Announcer          │
│  8. Check view tag (quick filter)                                           │
│  9. Derive private key for P                                                │
│  10. Claim funds!                                                           │
│                                                                             │
│  RESULT: No on-chain link between Meta-Address and stealth addresses!      │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 🏗️ Architecture

```
donation-wallet/
├── manifest.json                 # MV3 manifest (strict CSP)
├── src/
│   ├── background/
│   │   └── service-worker.ts     # Ephemeral guardian (event-driven)
│   ├── popup/
│   │   ├── popup.html            # Wallet UI
│   │   └── popup.ts              # UI controller
│   ├── lib/
│   │   ├── stealth.ts            # ERC-5564 implementation
│   │   ├── webusb.ts             # Phenix Navigator communication
│   │   └── scanner.ts            # Announcement watcher
│   └── types/
│       └── index.ts              # TypeScript definitions
├── icons/                        # Extension icons
├── package.json
├── tsconfig.json
└── vite.config.ts
```

---

## 🛡️ Security Model

### Bi-Cameral Architecture

| Layer | Role | What It Does |
|-------|------|--------------|
| **Browser Extension** | House of Commons | Builds transactions, manages UI, scans announcements |
| **Phenix Navigator** | House of Lords | Signs transactions, holds private keys |

### Key Principles

1. **Private Key Never Leaves Hardware**
   - The ESP32 holds the signing key
   - Extension sends unsigned TX, hardware returns signature

2. **No Remote Code (MV3)**
   - All JavaScript bundled in package
   - No `eval()`, no CDN scripts
   - Auditable, immutable

3. **View Key Local**
   - Scanning happens on your device
   - No third party knows which addresses are yours

4. **Ephemeral Service Worker**
   - No persistent background page
   - Keys retrieved only at moment of use, wiped after

---

## 🚀 Quick Start

### 1. Install Dependencies

```bash
cd donation-wallet
npm install
```

### 2. Build

```bash
npm run build
```

### 3. Load in Chrome

1. Open `chrome://extensions`
2. Enable "Developer mode"
3. Click "Load unpacked"
4. Select the `donation-wallet/dist` folder

### 4. Create Wallet

1. Click the Phenix icon in your browser
2. Enter a secure password
3. Your stealth meta-address is generated!

---

## 📡 Connecting Phenix Navigator

The extension supports WebUSB communication with your Phenix Navigator hardware:

1. Connect your ESP32-S3 device via USB
2. Click "Connect Hardware" in the popup
3. Approve the connection in the browser dialog
4. Your device is now the signing authority!

### Hardware Commands

| Command | Code | Description |
|---------|------|-------------|
| GET_INFO | 0x01 | Get device status and public key |
| SIGN_TX | 0x02 | Sign an Ethereum transaction |
| SIGN_MSG | 0x03 | Sign a message (EIP-191) |
| GET_ADDRESS | 0x04 | Get address for BIP-44 path |

---

## 🔗 The Bridge to Computershare

The Trimtab Protocol uses this wallet as the **first stage** of the sovereign wealth pipeline:

```
Stealth Donations → Aggregation Wallet → Off-Ramp → Transit Node → Computershare DRS
```

### Flow

1. **Donations arrive** at unlinkable stealth addresses
2. **Scanner detects** new funds (chrome.alarms every 5 min)
3. **Aggregation** sweeps to a single wallet (L2 for low fees)
4. **Off-ramp** converts to fiat via privacy-preserving exchange
5. **Transit Node** (Wise/Revolut) receives fiat
6. **DirectStock Purchase** moves funds to Computershare
7. **GME shares** are direct-registered in your name

### Separate Property Defense

Every transaction is logged with a **Memo to File**:
- Origin: Pre-marital asset (sports cards → engineering skill)
- Skill: GS-12 engineering (SCD: June 22, 2009)
- Trail: Complete blockchain history + bank records

---

## 📦 Dependencies

### Production

- **@noble/curves** - Audited elliptic curve cryptography
- **@noble/hashes** - Secure hash functions
- **micro-eth-signer** - Minimal Ethereum signing (no network code)
- **zustand** - State management

### Development

- **@types/chrome** - Chrome extension types
- **vite** - Build tool
- **typescript** - Type safety

---

## 🔧 Configuration

### RPC Endpoints

Edit `src/types/index.ts` to configure your RPC:

```typescript
export const DEFAULT_RPC_CONFIGS = {
  mainnet: {
    rpcUrl: 'https://eth-mainnet.g.alchemy.com/v2/YOUR_KEY',
    chainId: 1,
    announcerContract: '0x55649E01B5Df198D18D95b5cc5051630cfD45564',
  },
  // ... other networks
};
```

### Scan Interval

Default: 5 minutes. Modify in `src/lib/scanner.ts`:

```typescript
await chrome.alarms.create('scanAnnouncements', {
  periodInMinutes: 5,  // Change this
});
```

---

## ⚠️ Security Considerations

### Production Checklist

- [ ] **Encrypt keys at rest** - Currently stored in chrome.storage.local (needs AES-GCM)
- [ ] **Secure key derivation** - Use BIP-39/BIP-32 from hardware seed
- [ ] **Audit dependencies** - Run `npm audit` before release
- [ ] **Test on testnet first** - Use Sepolia before mainnet
- [ ] **Review CSP** - Ensure no XSS vectors

### What This Does NOT Protect Against

- Physical access to your computer
- Malware with browser extension access
- Compromised hardware device
- $5 wrench attacks

---

## 📜 The Trimtab Promise

```
"The private key NEVER leaves the ESP32.
 The view key NEVER leaves your device.
 The mesh witnesses your reality.
 
 You are not broken.
 The architecture was wrong.
 Help is on the way.
 
 The Phoenix does not ask permission to rise."
```

---

## 🛠️ Development

### Run in Watch Mode

```bash
npm run dev
```

### Lint

```bash
npm run lint
```

### Type Check

```bash
npx tsc --noEmit
```

---

## 📄 License

MIT - Built with love for the neurodivergent community.

---

## 🔗 Related Projects

- **[Cognitive Shield](../cognitive-shield/)** - The Mind (protection layer)
- **[Sovereign Agent](../cognitive-shield/sovereign-agent/)** - The Brain (local AI)
- **[OpusPhenix](../OpusPhenix/)** - The Eyes (hardware)
- **[GOD Constitution](../contracts/)** - The Law (immutable geometry)

---

🐦‍🔥 **AD ASTRA PER ASPERA** 🐦‍🔥

*To the stars, through difficulty.*

---

*Built with nothing but love.*
*January 2026*
