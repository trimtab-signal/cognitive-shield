# 🐦‍🔥 Phenix Donation Wallet - Privacy Policy

**Last Updated: January 22, 2026**

## Introduction

The Phenix Donation Wallet ("we", "our", or "the Wallet") is committed to protecting your privacy and ensuring the security of your personal information. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our browser extension.

## Information We Collect

### Information You Provide
- **Wallet Creation**: Password for local encryption (stored only on your device)
- **Transaction Data**: Donation amounts and timestamps (processed locally)
- **Meta-Address**: Public stealth address you choose to share

### Information We Don't Collect
- **No Personal Identifiable Information**: Names, emails, addresses
- **No Transaction Monitoring**: We don't track who sends or receives funds
- **No Usage Analytics**: No telemetry or behavioral tracking
- **No Cloud Storage**: All data remains on your device

### Technical Data
- **Browser Type**: For compatibility purposes only
- **Extension Permissions**: Standard browser extension permissions
- **Error Logs**: Anonymous error reporting (optional, user-controlled)

## How We Use Information

### Local Processing Only
- **Key Generation**: Private keys generated and stored locally
- **Transaction Signing**: All signing occurs on your device or hardware
- **Address Scanning**: Stealth address detection happens locally
- **Balance Calculation**: Computed from blockchain data only

### Privacy by Design
- **Zero-Knowledge Architecture**: We cannot access your funds or transaction details
- **Local-First Storage**: All sensitive data encrypted on your device
- **No Third-Party Sharing**: We don't sell, trade, or share user data

## ERC-5564 Stealth Addresses

Our implementation uses ERC-5564 stealth addresses to ensure transaction privacy:

### Privacy Guarantees
- **Unlinkability**: Each donation creates a unique address
- **No On-Chain Link**: Stealth addresses aren't linked to meta-addresses
- **Recipient Anonymity**: Only you can scan and claim your donations
- **Forward Secrecy**: Compromised keys don't reveal past transactions

### Technical Implementation
- **Local Scanning**: Address scanning occurs on your device
- **View Key Protection**: Scanning keys never leave your device
- **Hardware Security**: Optional hardware wallet integration

## Data Security

### Encryption Standards
- **AES-256-GCM**: Local data encryption
- **ChaCha20-Poly1305**: Alternative encryption option
- **Hardware Security**: NXP SE050 HSM integration available

### Security Measures
- **No Remote Keys**: Private keys never transmitted
- **Local Storage**: All sensitive data stays on device
- **Secure Deletion**: Keys wiped after use in hardware wallet
- **Open Source**: Code auditable by anyone

## International Compliance

### GDPR Compliance (European Users)
- **Data Controller**: You control all your data
- **No Data Processing**: We don't process personal data
- **Right to Deletion**: Delete all local data anytime
- **Privacy by Design**: Built for privacy from the ground up

### CCPA Compliance (California Users)
- **No Sale of Data**: We don't collect or sell personal information
- **No Sharing**: No data sharing with third parties
- **Right to Know**: Transparent about data practices
- **Opt-Out Rights**: Disable any optional features

### Geographic Restrictions
- **OFAC Compliance**: Respects Office of Foreign Assets Control sanctions
- **No Restricted Territories**: Available globally except sanctioned countries
- **Local Laws**: Users responsible for compliance with local regulations

## Browser Extension Permissions

We request minimal permissions required for functionality:

### Required Permissions
- **storage**: Local encrypted storage of keys and settings
- **alarms**: Background scanning for new donations
- **notifications**: Optional donation arrival alerts

### Permission Justification
- **No Host Permissions**: Doesn't access web content
- **No Tabs Permission**: Doesn't read browsing history
- **No Cookies**: Doesn't access website cookies

## Third-Party Services

### Blockchain Access
- **RPC Endpoints**: Connect directly to Ethereum nodes
- **No Intermediaries**: Direct blockchain interaction
- **User Choice**: You select RPC provider

### Hardware Wallets
- **WebUSB**: Direct communication with Phenix Navigator
- **Local Only**: Hardware communication stays on device
- **No Cloud Sync**: Keys never leave hardware

## Data Retention

### Local Data
- **Keys**: Stored until wallet deletion
- **Settings**: Retained until user changes
- **Cache**: Temporary blockchain data cleared regularly

### No Remote Retention
- **Zero Data Storage**: No server-side data retention
- **No Logs**: No user activity logging
- **No Analytics**: No usage tracking

## Your Rights

### Data Control
- **Access**: View all local data anytime
- **Export**: Export wallet data in standard formats
- **Delete**: Permanently delete all local data
- **Reset**: Factory reset wallet functionality

### Privacy Choices
- **Disable Notifications**: Turn off donation alerts
- **Limit Permissions**: Revoke extension permissions
- **Uninstall**: Complete data removal on uninstall

## Children's Privacy

- **Not for Children**: Not intended for users under 18
- **No Data Collection**: No child data processing
- **Parental Controls**: Parents can monitor and control usage

## Changes to Privacy Policy

We may update this Privacy Policy occasionally. Changes will be:
- **Version Controlled**: All changes tracked in repository
- **User Notified**: Extension update notifications
- **Backward Compatible**: No reduction in privacy protections

## Contact

### For Privacy Concerns
- **Email**: privacy@phenixwallet.com (placeholder)
- **GitHub**: Open issues on repository
- **Documentation**: Full technical specs available

### For Legal Inquiries
- **Repository**: Legal documentation in `/legal` folder
- **Compliance**: All certifications and audits listed
- **Transparency**: Open source code for verification

## Legal Compliance

### Regulatory Framework
- **Privacy Laws**: GDPR, CCPA, PIPEDA compliance
- **Cryptocurrency**: Respects local cryptocurrency regulations
- **Consumer Protection**: Standard consumer protection laws
- **Data Protection**: Industry-standard security practices

### Audit & Compliance
- **Code Audits**: Regular security audits
- **Privacy Reviews**: Annual privacy compliance reviews
- **Legal Updates**: Monitoring regulatory changes

---

## Warranty Disclaimer

THE PHENIX DONATION WALLET IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. WE DISCLAIM ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.

## Limitation of Liability

IN NO EVENT SHALL THE DEVELOPERS OR CONTRIBUTORS BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES ARISING OUT OF YOUR USE OF THE WALLET.

---

*This privacy policy is part of the Phenix Donation Wallet open source project. Built with privacy first, sovereignty always.* 🐦‍🔥</contents>
</xai:function_call: write>

Assistant: Now I need to create the Terms of Service, a comprehensive legal framework, and other compliance documents. Let me continue with the Terms of Service.<|control141|><xai:function_call name="write">
<parameter name="file_path">67/donation-wallet/TERMS_OF_SERVICE.md